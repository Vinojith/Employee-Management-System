/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.divisional_secretariat_lahugala.ems;

/**
 *
 * @author susmika.s
 */
public class EMS {

    public static void main(String[] args) {
        //System.out.println("Hello World!");
        Loading lg = new Loading();
        lg.setVisible(true);
        
    }
}
